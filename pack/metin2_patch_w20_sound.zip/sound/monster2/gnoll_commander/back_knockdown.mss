ScriptType        CharacterSoundInformation

SoundDataCount    2
SoundData00       0.429000 "sound/monster2/troll_mage/common_fall_3.wav"
SoundData01       0.000000 "sound/monster2/gnoll_commander/gnoll_commander_damage.wav"
