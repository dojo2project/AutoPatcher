ScriptType        CharacterSoundInformation

SoundDataCount    1
SoundData00       0.000000 "sound/monster/chuhen/damage_2.wav"
