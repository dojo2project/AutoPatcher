ScriptType        CharacterSoundInformation

SoundDataCount    2
SoundData00       0.396000 "sound/monster/thief2/drop1.wav"
SoundData01       0.000000 "sound/monster/barbarian_soldier/dead_2.wav"
